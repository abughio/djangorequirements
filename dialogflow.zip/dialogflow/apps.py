from django.apps import AppConfig


class DialogflowConfig(AppConfig):
    name = 'dialogflow'
